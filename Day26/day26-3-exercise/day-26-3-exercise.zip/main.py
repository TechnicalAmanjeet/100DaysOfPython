

# Write your code above 👆

print(result)


